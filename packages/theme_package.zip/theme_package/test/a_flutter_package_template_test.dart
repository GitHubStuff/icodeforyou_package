import 'package:flutter_test/flutter_test.dart';
// Improves readability of examples
// ignore: unused_import
import 'package:theme_package/theme_package.dart';

void main() {
  test('adds one to input values', () {});
}
